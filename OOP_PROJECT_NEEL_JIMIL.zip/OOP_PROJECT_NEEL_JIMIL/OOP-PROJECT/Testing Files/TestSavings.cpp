#include <iostream>
#include "Savings.h"
using namespace std;

void testSavings() {
    cout << "Starting Savings Tests..." << endl;
    
    // Test default constructor
    Savings defaultSavings;
    if (defaultSavings.getGoal() == "NULL") {
        cout << "PASS: Default constructor initializes goal to 'NULL'." << endl;
    } else {
        cout << "FAIL: Default constructor did not initialize goal to 'NULL'." << endl;
    }

    // Test parameterized constructor
    int balance = 1500;
    string type = "TestSavings";
    string goal = "Buy a laptop";
    Savings paramSavings(balance, type, goal);
    if (paramSavings.getGoal() == goal) {
        cout << "PASS: Parameterized constructor correctly sets goal." << endl;
    } else {
        cout << "FAIL: Parameterized constructor did not set the correct goal." << endl;
    }

    // Test change goal
    string newGoal = "Buy a house";
    paramSavings.ChangeGoal(newGoal);
    if (paramSavings.getGoal() == newGoal) {
        cout << "PASS: ChangeGoal correctly updates the goal." << endl;
    } else {
        cout << "FAIL: ChangeGoal did not update the goal correctly." << endl;
    }

    cout << "Savings Tests Completed!" << endl;
}

int main() {
    testSavings();
    return 0;
}
