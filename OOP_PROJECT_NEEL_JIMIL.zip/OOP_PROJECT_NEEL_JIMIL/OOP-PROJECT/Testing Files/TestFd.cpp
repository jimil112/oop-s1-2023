#include <iostream>
#include "Fd.h"
using namespace std;

void testFd() {
    cout << "Starting Fd Tests..." << endl;
    
    // === Testing the Default Constructor ===
    // Test if the default constructor initializes the 'term' member variable to 0
    Fd defaultFd;
    if (defaultFd.getTerm() == 0) {
        cout << "PASS: Default constructor initializes term to 0." << endl;
    } else {
        cout << "FAIL: Default constructor did not initialize term to 0." << endl;
    }

    // === Testing the Parameterized Constructor ===
    // Creating an Fd object with predetermined values for balance, type, and term.
    int balance = 1000;
    string type = "TestFd";
    int termValue = 3; // 3-year term
    Fd paramFd(balance, type, termValue);
    
    // Test if the parameterized constructor correctly sets the 'term'
    if (paramFd.getTerm() == termValue) {
        cout << "PASS: Parameterized constructor correctly sets term." << endl;
    } else {
        cout << "FAIL: Parameterized constructor did not set the correct term." << endl;
    }

    // === Testing the setTerm Function ===
    // Updating the term using setTerm method.
    int newTerm = 5; // 5-year term
    paramFd.setTerm(newTerm);

    // Test if the setTerm function correctly updates the 'term'
    if (paramFd.getTerm() == newTerm) {
        cout << "PASS: setTerm correctly updates the term." << endl;
    } else {
        cout << "FAIL: setTerm did not update the term correctly." << endl;
    }

    // Indicating the end of Fd tests.
    cout << "Fd Tests Completed!" << endl;
}

int main() {
    // Executing the Fd tests.
    testFd();
    return 0;
}
