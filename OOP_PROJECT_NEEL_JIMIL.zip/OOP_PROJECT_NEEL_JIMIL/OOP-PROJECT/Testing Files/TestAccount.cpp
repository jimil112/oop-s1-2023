#include "Account.h"
#include <iostream>
#include <cassert>

void test_DefaultConstructor() {
    Account acc;

    assert(acc.getBalance() == 0);
    assert(acc.getAccType() == "NULL");
}

void test_ParameterizedConstructor() {
    Account acc(5000, "Savings");

    assert(acc.getBalance() == 5000);
    assert(acc.getAccType() == "Savings");
}

void test_SettersAndGetters() {
    Account acc;

    acc.setBalance(2500);
    acc.setAccType("Checking");

    assert(acc.getBalance() == 2500);
    assert(acc.getAccType() == "Checking");
}

int main() {
    std::cout << "Running Account default constructor test...\n";
    test_DefaultConstructor();
    std::cout << "Default constructor test passed!\n\n";

    std::cout << "Running Account parameterized constructor test...\n";
    test_ParameterizedConstructor();
    std::cout << "Parameterized constructor test passed!\n\n";

    std::cout << "Running setters and getters test...\n";
    test_SettersAndGetters();
    std::cout << "Setters and getters test passed!\n\n";

    std::cout << "All tests passed!\n";

    return 0;
}
