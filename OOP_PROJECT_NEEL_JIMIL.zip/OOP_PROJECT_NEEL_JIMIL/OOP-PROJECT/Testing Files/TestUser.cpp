#include <iostream>
#include "User.h"
using namespace std;

// Derived class from User to implement the greeting method
class TestUser : public User {
public:
    TestUser() : User() {}
    TestUser(string username, long password) : User(username, password) {}

    void greeting() const override {
        cout << "Hello, " << getusername() << "!" << endl;
    }
};

// Function to run all tests
void runTests() {
    cout << "Starting Tests..." << endl;

    // Test default constructor
    TestUser defaultUser;
    defaultUser.greeting();
    cout << "Default username: " << defaultUser.getusername() << endl;
    cout << "Default password: " << defaultUser.getpassword() << endl;
    
    // Test parameterized constructor with valid inputs
    TestUser validUser("TestUser1", 1234567890);
    validUser.greeting();
    cout << "Username: " << validUser.getusername() << endl;
    cout << "Password: " << validUser.getpassword() << endl;
    
    // Test setters
    validUser.setusername("ChangedUser");
    validUser.setpassword(9876543210);
    cout << "After using setters - Username: " << validUser.getusername() << endl;
    cout << "After using setters - Password: " << validUser.getpassword() << endl;

    // Test password validation (Note: this will prompt the user)
    cout << "\nTesting password validation. Please enter invalid passwords for prompts." << endl;
    TestUser invalidUser("TestUser2", 12345);
    
    cout << "Tests Completed!" << endl;
}

int main() {
    runTests();
    return 0;
}
