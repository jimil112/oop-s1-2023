#include "Loan.h"
#include <iostream>
#include <cassert>
#include <sstream>

// Function to test 'askForLoanAmount()' function
void testAskForLoanAmount() {
    Loan loan;
    // Redirect cin to read from our stringstream
    std::stringstream input("700\n1500");  // First input is invalid, second is valid.
    std::cin.rdbuf(input.rdbuf());
    
    loan.askForLoanAmount();

    assert(loan.getLoanAmount() == 1500.0f && "testAskForLoanAmount() failed.");
    std::cout << "testAskForLoanAmount() passed.\n";
}

// Function to test 'getLoanAmount()' function
void testGetLoanAmount() {
    Loan loan;

    // Note: We use the default constructor, which initializes loanAmount to 0.0f.
    assert(loan.getLoanAmount() == 0.0f && "testGetLoanAmount() failed.");
    std::cout << "testGetLoanAmount() passed.\n";
}

int main() {
    std::cout << "Starting Loan tests...\n";
    
    testAskForLoanAmount();
    testGetLoanAmount();

    std::cout << "All Loan tests completed!\n";

    return 0;
}
